--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.2 (Ubuntu 13.2-1.pgdg20.04+1)
-- Dumped by pg_dump version 13.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE d6q2hcpo4sua12;
--
-- Name: d6q2hcpo4sua12; Type: DATABASE; Schema: -; Owner: qzhoeaprdhimqj
--

CREATE DATABASE d6q2hcpo4sua12 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.UTF-8';


ALTER DATABASE d6q2hcpo4sua12 OWNER TO qzhoeaprdhimqj;

\connect d6q2hcpo4sua12

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: account; Type: TABLE; Schema: public; Owner: qzhoeaprdhimqj
--

CREATE TABLE public.account (
    id integer NOT NULL,
    usc_id character varying(20),
    username character varying(100),
    major character varying(100),
    email character varying(100),
    passcode character varying(64),
    picture character varying(2083),
    is_admin smallint,
    CONSTRAINT account_id_check CHECK ((id > 0))
);


ALTER TABLE public.account OWNER TO qzhoeaprdhimqj;

--
-- Name: account_id_seq; Type: SEQUENCE; Schema: public; Owner: qzhoeaprdhimqj
--

CREATE SEQUENCE public.account_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_id_seq OWNER TO qzhoeaprdhimqj;

--
-- Name: account_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: qzhoeaprdhimqj
--

ALTER SEQUENCE public.account_id_seq OWNED BY public.account.id;


--
-- Name: place; Type: TABLE; Schema: public; Owner: qzhoeaprdhimqj
--

CREATE TABLE public.place (
    id integer NOT NULL,
    place_name character varying(100),
    abbreviation character varying(10),
    place_address character varying(200),
    qr_code_token character varying(100),
    picture character varying(2083),
    capacity integer,
    current_numbers integer DEFAULT 0,
    open_time time without time zone,
    close_time time without time zone,
    CONSTRAINT place_id_check CHECK ((id > 0))
);


ALTER TABLE public.place OWNER TO qzhoeaprdhimqj;

--
-- Name: place_id_seq; Type: SEQUENCE; Schema: public; Owner: qzhoeaprdhimqj
--

CREATE SEQUENCE public.place_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.place_id_seq OWNER TO qzhoeaprdhimqj;

--
-- Name: place_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: qzhoeaprdhimqj
--

ALTER SEQUENCE public.place_id_seq OWNED BY public.place.id;


--
-- Name: visit_history; Type: TABLE; Schema: public; Owner: qzhoeaprdhimqj
--

CREATE TABLE public.visit_history (
    id integer NOT NULL,
    account_id integer,
    place_id integer,
    enter_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    leave_time timestamp without time zone,
    CONSTRAINT visit_history_id_check CHECK ((id > 0))
);


ALTER TABLE public.visit_history OWNER TO qzhoeaprdhimqj;

--
-- Name: visit_history_id_seq; Type: SEQUENCE; Schema: public; Owner: qzhoeaprdhimqj
--

CREATE SEQUENCE public.visit_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.visit_history_id_seq OWNER TO qzhoeaprdhimqj;

--
-- Name: visit_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: qzhoeaprdhimqj
--

ALTER SEQUENCE public.visit_history_id_seq OWNED BY public.visit_history.id;


--
-- Name: account id; Type: DEFAULT; Schema: public; Owner: qzhoeaprdhimqj
--

ALTER TABLE ONLY public.account ALTER COLUMN id SET DEFAULT nextval('public.account_id_seq'::regclass);


--
-- Name: place id; Type: DEFAULT; Schema: public; Owner: qzhoeaprdhimqj
--

ALTER TABLE ONLY public.place ALTER COLUMN id SET DEFAULT nextval('public.place_id_seq'::regclass);


--
-- Name: visit_history id; Type: DEFAULT; Schema: public; Owner: qzhoeaprdhimqj
--

ALTER TABLE ONLY public.visit_history ALTER COLUMN id SET DEFAULT nextval('public.visit_history_id_seq'::regclass);


--
-- Data for Name: account; Type: TABLE DATA; Schema: public; Owner: qzhoeaprdhimqj
--

COPY public.account (id, usc_id, username, major, email, passcode, picture, is_admin) FROM stdin;
\.
COPY public.account (id, usc_id, username, major, email, passcode, picture, is_admin) FROM '$$PATH$$/4004.dat';

--
-- Data for Name: place; Type: TABLE DATA; Schema: public; Owner: qzhoeaprdhimqj
--

COPY public.place (id, place_name, abbreviation, place_address, qr_code_token, picture, capacity, current_numbers, open_time, close_time) FROM stdin;
\.
COPY public.place (id, place_name, abbreviation, place_address, qr_code_token, picture, capacity, current_numbers, open_time, close_time) FROM '$$PATH$$/4006.dat';

--
-- Data for Name: visit_history; Type: TABLE DATA; Schema: public; Owner: qzhoeaprdhimqj
--

COPY public.visit_history (id, account_id, place_id, enter_time, leave_time) FROM stdin;
\.
COPY public.visit_history (id, account_id, place_id, enter_time, leave_time) FROM '$$PATH$$/4008.dat';

--
-- Name: account_id_seq; Type: SEQUENCE SET; Schema: public; Owner: qzhoeaprdhimqj
--

SELECT pg_catalog.setval('public.account_id_seq', 4, true);


--
-- Name: place_id_seq; Type: SEQUENCE SET; Schema: public; Owner: qzhoeaprdhimqj
--

SELECT pg_catalog.setval('public.place_id_seq', 3, true);


--
-- Name: visit_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: qzhoeaprdhimqj
--

SELECT pg_catalog.setval('public.visit_history_id_seq', 5, true);


--
-- Name: account account_email_key; Type: CONSTRAINT; Schema: public; Owner: qzhoeaprdhimqj
--

ALTER TABLE ONLY public.account
    ADD CONSTRAINT account_email_key UNIQUE (email);


--
-- Name: account account_pkey; Type: CONSTRAINT; Schema: public; Owner: qzhoeaprdhimqj
--

ALTER TABLE ONLY public.account
    ADD CONSTRAINT account_pkey PRIMARY KEY (id);


--
-- Name: place place_abbreviation_key; Type: CONSTRAINT; Schema: public; Owner: qzhoeaprdhimqj
--

ALTER TABLE ONLY public.place
    ADD CONSTRAINT place_abbreviation_key UNIQUE (abbreviation);


--
-- Name: place place_pkey; Type: CONSTRAINT; Schema: public; Owner: qzhoeaprdhimqj
--

ALTER TABLE ONLY public.place
    ADD CONSTRAINT place_pkey PRIMARY KEY (id);


--
-- Name: place place_place_name_key; Type: CONSTRAINT; Schema: public; Owner: qzhoeaprdhimqj
--

ALTER TABLE ONLY public.place
    ADD CONSTRAINT place_place_name_key UNIQUE (place_name);


--
-- Name: visit_history visit_history_pkey; Type: CONSTRAINT; Schema: public; Owner: qzhoeaprdhimqj
--

ALTER TABLE ONLY public.visit_history
    ADD CONSTRAINT visit_history_pkey PRIMARY KEY (id);


--
-- Name: visit_history visit_history_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: qzhoeaprdhimqj
--

ALTER TABLE ONLY public.visit_history
    ADD CONSTRAINT visit_history_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.account(id) ON DELETE CASCADE;


--
-- Name: visit_history visit_history_place_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: qzhoeaprdhimqj
--

ALTER TABLE ONLY public.visit_history
    ADD CONSTRAINT visit_history_place_id_fkey FOREIGN KEY (place_id) REFERENCES public.place(id) ON DELETE CASCADE;


--
-- Name: DATABASE d6q2hcpo4sua12; Type: ACL; Schema: -; Owner: qzhoeaprdhimqj
--

REVOKE CONNECT,TEMPORARY ON DATABASE d6q2hcpo4sua12 FROM PUBLIC;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: qzhoeaprdhimqj
--

REVOKE ALL ON SCHEMA public FROM postgres;
REVOKE ALL ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO qzhoeaprdhimqj;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- Name: LANGUAGE plpgsql; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON LANGUAGE plpgsql TO qzhoeaprdhimqj;


--
-- PostgreSQL database dump complete
--

